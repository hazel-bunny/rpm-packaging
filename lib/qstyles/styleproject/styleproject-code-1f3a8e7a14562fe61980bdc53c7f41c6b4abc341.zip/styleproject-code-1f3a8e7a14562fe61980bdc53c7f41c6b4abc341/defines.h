#ifndef DEFINES_H
#define DEFINES_H

#ifndef HASXCB
#define HASXCB 0
#endif

#ifndef HASX11
#define HASX11 0
#endif

#ifndef HASDBUS
#define HASDBUS 0
#endif

#ifndef DEBUG
#define DEBUG 0
#endif

#ifndef HASKF5
#define HASKF5 0
#endif

#endif //DEFINES_H
